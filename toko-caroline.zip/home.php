<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Fresh Box</title>
</head>
<body>
    <?php include "menu.php"; ?>
</body>
</html>